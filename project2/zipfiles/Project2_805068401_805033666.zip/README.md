																Project 2: Clustering Newsgroup data using K-means


																Vijay Ravi							Zhi Ming Chua


---------------------------------------------------------------------------------------------------------------------------------------

project2Part1 - NUMBER OF TERMS IN TFxIDF REPRESENTATION. 

---------------------------------------------------------------------------------------------------------------------------------------

project2Part2 - NO DIMENSION REDUCTION | 2 CLASSES

---------------------------------------------------------------------------------------------------------------------------------------

project2Part3a - PERCENTAGE OF VARIANCE RETAINED IN TRUNCATED DATA

project2Part3b - SVD| DIFFERENT r| 2 CLASSES

project2Part3c - NMF| DIFFERENT r| 2 CLASSES

---------------------------------------------------------------------------------------------------------------------------------------

project2Part4 - SVD| BEST r| 2 CLASSES | PROJECTION 

project2Part4a - NMF| BEST r| 2 CLASSES | PROJECTION

project2Part4b- NMF| BEST r VALUE | NORM ONLY TRANSFORMATION | 2 CLASSES| PROJECTION

project2Part4c - NMF| BEST r VALUE | LOG ONLY TRANSFORMATION | 2 CLASSES| PROJECTION

project2Part4d - NMF| BEST r VALUE | NORM+LOG TRANSFORMATION | 2 CLASSES| PROJECTION

project2Part4e - NMF| BEST r VALUE | LOG+NORM TRANSFORMATION | 2 CLASSES| PROJECTION

---------------------------------------------------------------------------------------------------------------------------------------

project2Part5 - SVD| DIFFERENT r| 20 CLASSES

project2Part5a - NMF| DIIFERENT r| 20 CLASSES

project2Part5b - NMF| BEST r VALUE | NORM ONLY TRANSFORMATION | 20 CLASSES

project2Part5c - NMF| BEST r VALUE | LOG ONLY TRANSFORMATION | 20 CLASSES

project2Part5d - NMF| BEST r VALUE | NORM+LOG TRANSFORMATION | 20 CLASSES

project2Part5e - NMF| BEST r VALUE | LOG+NORM TRANSFORMATION | 20 CLASSES

---------------------------------------------------------------------------------------------------------------------------------------