

Winter 2018 - ECE 219: Large-Scale Data Mining: Models and Algorithms 



Project 4: Regression Analysis

Dataset: Network Backup Dataset



Part 1 : Dataset Visualization

Part 2 : Prediction using Regression

Part 2a : Linear Regression Model

Part 2b : Random Forest Regression Model

Part 2c : Neural Networks

Part 2d: Polynomial Regression

Part 2e: K nearest Neighbour 