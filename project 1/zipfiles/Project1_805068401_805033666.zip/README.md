

partA - Histogram Plotting

partB - Number of terms in TFIDF Representation

partC - 10 Significant terms in each class

partD - Number of terms in LSI dimension reduction

partD1 - Number of terms in NMF dimension reduction

partE - LSI| SVM| Different penalties

partEb - LSI| NMF| Different penalties

partE1 - 5-fold Cross validation | LSI| SVM

partE1b - 5 fold Cross Validation | NMF| SVM

partF - Multinomial Naive Bayes | No dimension reduction

partFb - Multinomial Naive Bayes | NMF

partG - Logistic Regression | No regularization | LSI

partGb - Logistic Regression | No regularization | NMF

partG1 - Logistic Regression | Regularization | l1/l2| LSI

partG1b - Logistic Regression | Regularization | l1/l2| NMF

partH - OneVsOne Classifier | SVM| LSI

partHb - OneVsOne Classifier | SVM| NMF

partI - OneVsRest Classifier | SVM | LSI

PartIb - OneVsRest Classifier | SVM| NMF

partJ - Multiclass Naive Bayes Classifier


